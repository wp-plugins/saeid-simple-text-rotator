=== Saeid Simple Text Rotator ===
Contributors: hojjatmr
Donate link: mailto: peratik@gmail.com
Tags: Text Rotator, effect, fades, flip, rotation, rotator, spin, Change Text. 
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later

Saeid Simple Text Rotator uses jQuery Super Simple Text Rotator by Pete R. on a simple shortcode to rotate your texts!


== Description ==
Saeid Simple Text Rotator uses jQuery Super Simple Text Rotator by Pete R. on a simple shortcode to rotate your texts! There is a simple shortcode you can use it anywhere on your WordPress to rotate your texts.

Saeid Simple Text Rotator Shortcode details

[saeidrotate class="" animation="" separator="" speed=""]text1, text2, text3, text4, ...[/saeidrotate]

Default values:
    class => rotate
    animation => dissolve
	separator => ,
	speed => 2000

class: class name of outputed <span> tag

animation: You can pick the way it animates when rotating through words. Options are dissolve (default), fade, flip, flipUp, flipCube, * * flipCubeUp and spin.

separator: If you don't want commas to be the separator, you can define a new separator (|, &, * etc.) by yourself using this field.

speed: How many milliseconds until the next word show.

== Plugin Features ==
* Shortcode System
* Responsive and cross browser support. 
* The Rotator Text Fade and Animations. 
* Very Lightweight, Only 20.00KB.

All the above options are Changeable via short-code.

== Installation ==
Use WordPress 'Add New Plugin' feature, searching `Saeid Simple Text Rotator`, or download the archive and:

1. Unzip the archive on your computer.
2. Upload `Saeid Simple Text Rotator` directory to the `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Use short-code [saeidrotate][/saeidrotate] in page, post.

== Frequently Asked Questions ==
Not yet asked!

== Screenshots ==
Not found!
	
== Changelog ==

= 1.0 =
* Initial Release

== Upgrade Notice ==
No upgrade available.